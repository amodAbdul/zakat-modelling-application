package com.example.albani.zakkatmodel;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Explode;
import android.transition.Transition;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class sheep extends AppCompatActivity {
    int a,b,c,total;
    String m,n,o,p;
    EditText name,cash,sheep,bank;
    Button compute,reset,back;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
        Transition transition = new Explode();

        transition.setStartDelay(250);
        transition.setDuration(800);

        getWindow().setEnterTransition(transition);
        getWindow().setExitTransition(transition);
        setContentView(R.layout.activity_sheep);
        name=findViewById(R.id.name);
        sheep=findViewById(R.id.sheep);

        compute=findViewById(R.id.btnsave);
        add();
    }

    public  void back(View view){
        Intent Intent = new Intent(getApplicationContext(), livemenu.class);
        startActivity(Intent);

    }
    public  void reset(View view){

        name.setText("");
        sheep.setText("");

    }
    public int trypersInt(String value, int defaultv){

        try {
            return  Integer.parseInt(value);
        }catch (NumberFormatException nfe){return 0; }
    }
    public  void add(){
        compute.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {

                                           String payer = name.getText().toString().trim();
                                           String md=sheep.getText().toString();



                                          int  q= trypersInt(md,0);
                                           b= trypersInt(md,0);
                                           if (payer.equals("")) {
                                               Toast.makeText(sheep.this, "Empty field is not Accepted", Toast.LENGTH_SHORT).show();

                                           }
                                           else if (b<40) {

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Sorry, no Zakat for "+b +" sheep/goats" );
                                           }
                                           else if (b>39 && b<121) {

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Sheeps/Goats:"+q+"\n Zakat due is one female sheep/goat of one years old" );
                                           }
                                           else if (b> 120 && b<201){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Sheeps/Goats:"+q+"\n Zakat due is two female sheep/goats (of 1 year each)" );
                                           }
                                           else{
                                               b=b/100;
                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Sheeps/Goats:"+q+"\n Zakat due is "+b+" female sheep/goats each of one year old" );

                                           }

                                       }
                                   }
        );
    }
    public void showmessage(String title, String message){

        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);

        builder.setMessage(message);

        builder.show();
    }

}
