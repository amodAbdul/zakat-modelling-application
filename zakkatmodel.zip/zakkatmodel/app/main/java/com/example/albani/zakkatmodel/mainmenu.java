package com.example.albani.zakkatmodel;

import android.app.ActivityOptions;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;

import com.google.android.gms.ads.AdView;

public class mainmenu extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    WebView view;
    String text;
    private AdView mAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainmenu);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        mAdView = findViewById(R.id.adView);


       view = findViewById(R.id.web);

        text = "<html><body >" +
                "<center> <img src=\"file:///android_asset/zk2.jpg\" width=\"300\" height=\"120\" /></center><br> "+
                "<p align=\"justify\"><b><center><font color='green'>WHAT IS ZAKAT</font></center></b>" +
                "</p><p align=\"justify\">Zakkat is fixed portion of wealth out of each and every kind wealth liable to Zakat of a muslims to be paid yearly from rich to the poor for the benefits of Muslims Community." +
                "Zakat Modelling Application Is an automated system that show how to compute different zakat categories in a comportable manner in other to provide easy means for the end user`s to see the benefit of computer " +
                "in zakat processes\"</string>\n </p>" +
                " <br><center><img src=\"file:///android_asset/zk1.jpg\" width=\"300\" height=\"120\" /></center> "+
                "<p align=\"justify\"><b><center><font color='green'>Zakat and its Types</font></center></b><hr>" +
                "<p align=\"justify\"> The term Zakat refers to a certain fixed portion of wealth out of each and every kind of wealth liable to Zakat of a Muslim to be paid yearly for the benefit of the poor in the Muslim community. " +
                "The payment of Zakat is obligatory as it is the third pillar of Islam. Zakat is the major economic means" +
                " for establishing social justice and also balances the mode of living between the rich and the poor in Muslim community. " +
                "Different scholars have defined Zakat, among which are:-" +
    "<br><br><b>*1)	Irfan (1996):</b> defined Zakat as the compulsory levy on the income and wealth of Muslim which is meant to clean and purify and signified justness, integrity and vindication as well as increase " +"" +
                "and growth."+
       " <br><b><br>*2)	Mawdudi (1985):</b> defined Zakat as purity and cleanliness and act of setting aside a portion of a Muslim wealth for the needy and poor, with which are attained. He added that Zakat was enjoined by Allah upon Muslims as a test soul enjoined upon the people of Ibrahim (Qur’an21:73)," +
                " Isa (Qur’an19:31) and Isma’il (Qur’an19:55). <br>" +
                "<br><br><b>*3)	Isma’il (1990):</b> stated that Zakat literally means growth and cleanliness. It also refers to both the compulsory and voluntary charity as well as feeding others, compulsorily and voluntarily. It was enjoined upon Muslims in the second year of Hijrah, to be collected from the rich and given to the poor."+
        "<br><br><b>*4)	IbnulQayyim (1999):</b> stated Zakat as that portion of a man’s wealth which was designated for to the poor. He again said that it was derived from the Arabic verbal root meaning “to purify”, or “to increase” or “to bless”. He further clarified that it found origin in Allah’s (SWT) command in the Holy Qur’an “take sadaqah (Zakat) from their property and to purify and sanctify them”(Qur’an 9:103)."+
        "<br><br><b>*5)	Samir (2005):</b> stated that, Zakat (alms) is the name of what a believer returns out of his or her wealth to the neediest of Muslims for the sake of the Almighty Allah. It is called Zakat because the word Zakat is from Zakat which means, to increase, purify and bless."+
        "Zakat could therefore, be defined as the third of the five pillars of Islam which is obligatory to every Muslim at a specific amount of wealth at a specific level and given out to a specific group of people among the Muslims."+
        "Zakat is of two types: the obligatory and the non-obligatory (zakatulfitr). This project is concerned with the obligatory one."+
        "<br><br><b>*6)	Hussain (1997):</b> stated that Zakat refers to spending a fixed portion of one's wealth for the poor and needy in the society. Giving money for charity is highly commendable; however zakat is different because it is obligatory."+

                " <br><center><img src=\"file:///android_asset/islam2.png\" width=\"300\" width=\"10\" /> </center>"+
                "<p align=\"justify \"><b><center><font color='green'>Who is obliged to pay Zakat? </font></center></b></p>"+
                "<p align=\"justify \">All scholars agreed that Zakat is compulsory upon Muslims who are adults, free (not slaves), mentally stable and possess Nisab and Hawl, but opinions differed on orphans, insane and debtors.<br>" +
                "Some scholars like Ali, Ibn Umar, Jabir and Aisha (from the Sahabah) and Malik, Shafi’ (from early scholars after the Sahabahs) agreed that Zakat is compulsory on the wealth of orphans and insane but not slaves (because a slave has no full" +
                " possession of his wealth) and debtors.<br >Sabiq (1995) said that every Muslim who has Nisab possessed for at least one lunar year must pay Zakat. He further added that the guardian of a child and a mentally retarded person must pay Zakat on his behalf from his property if it constitutes Nisab.\n" +

                "From the cited work above, it will be concluded that every Muslim must pay Zakat young or old, male or female sane or insane except according to Malik (1982) and his co-scholars that slave and indebted (whose balance after paying off his debts is less than nisab) cannot pay Zakat.\n </p>"+
                "<p align=\"justify \"><b><center><font color='green'>Zakat on Gold And Silver </font></center></b></p>"+

                "<p align=\"justify\">According to Malik, Zakat on gold and silver is assessed by the weight and not by the number of dinars or silver coins. Consequently Mawdudi (1985) said that" +
                " the Nisab of gold equals 85g while that of silver equals 595g. Irfan (1996) stated that the Nisab of gold and silver are " +
                "respectively 92g (or 3 troy ounces) and 796g (or 26 troy ounces). Other scholars agreed that 200 dirhams of silver equal 612.36g while 20 dinars of gold equals 87.48g.\n" +
                "<br>But most or almost the entire above estimate lacked concord weight of gold and silver. Jaabir (1986) suggested that the adoption of the method used by Maliki’s school of law" +
                " (in Madina) showed that a dinar weighs 72 grains of barley approximately 3.5g implying that 20 dinars = 70g. Similarly, a dirham of silver wheighs 51 grains of barley approximately 2.3g" +
                " implying that 200 dirhams = 460g.\n<br>" +
                "However, the measure used by the department of Zakat and endowment ministry of religious affairs is 20 dinars equivalent of gold which equals 85g, while that of 200 dirhams of silver equals 595g." +
                " The Zakat due on both gold and silver is one fourtieth (1/40).\n" +
                "In the case of cash, the Nisab is the equilavent of the exchange rate of 85g of silver or more with respect to a given currency. The system will, however provide the means of" +
                " setting the current Nisab (in naira) that is equivalent to 20 dinars or 85g of gold (since it varies from time to time according to naira value un world markets).\n</p>"+
                "<p align=\"justify \"><b><center><font color='green'><u>Zakat due on Livestock </u></font></center></b></p>"+

"<p align=\"justify \"> Cattle, including camels, cows, sheep and goats, that are freely grazed and are raised for trade and" +
                " production." +
                " For Zakat to be obligatory, the number must reach the nisaab. The nisaab of camels is five, of cows 30, of sheep" +
                " and goats, 40. By freely grazing is meant the animal goes out to feed without the owner buying or bringing it feed or hay. If it is not a grazing animal, there is no Zakat in the stock by itself. The stock will, however, be considered as articles of trade, then will be assessed for Zakat as articles of trade when the profit earned from their sale rich the amount by itself or in combination with other articles of the trade.\n" +
                "All scholars have agreed on the Zakat due on livestock. The following tables summarised the respective levy on each " +
                "category of livestock.\n</p>"+
                "<p align=\"justify \"><b><center><font color='green'><u>Zakat due on Camels </u></font></center></b></p>"+


                "<table border=\"2\"><tr>"+
                "<th>QUANTITY OF CAMELS</th><th>ZAKAT TO PAID</th></tr>" +
                "<tr><td>5-9 Camels</td> <td>sheep or goat of 1-2 years old</td></tr>" +
                "<tr><td>10-14 Camels</td><td> sheep or goats of 1-2 years old</td></tr>" +
                "<tr><td>15-19 camels</td><td> sheep or goats of 1-2 years old</td></tr>" +
                "<tr><td>20-24 camels</td><td> sheep or goats of 1-2 years old</td><tr>" +
                "<tr><td>25-35 camels</td><td> 2-year old she-camel</td></tr>" +
                "<tr><td>36-45 camels</td><td> 2-3 years old she-camel</td></tr>" +
                "<tr><td>46-60 camels</td><td> 3-4 years old she-camel</td" +
                "></tr>" +
                "<tr><td>61-75 camels</td><td>A 4-5 years old she-camel</td></tr>" +
                "<tr><td>76-90 camels</td><td> (3-4 years old she-camel)</td></tr>" +
                "<tr><td>91-120 camels</td><td> (3-4 years old she-camel)</td></tr></table>"+
                "<br><p align=\"justify\"><b>NB:</b>After 120 camels, on every additional 40 a 2-years old she-camel is the Zakat while a 3-years " +
                "old she-camel is due on every additional 50 camels.<br>"+

                "<p align=\"justify \"><b><center><font color='green'><u>Zakat due on Cows</u></font></center></b></p>"+
"<table border=\"2\">" +
                "<table border=\"2\"><tr><th>NUMBER OF COWS</th><th>ZAKAT TO BE PAID</th><tr>" +
                "<tr> <td>30-39 COWS </td><td> 2-year old she-cow</td></tr>" +

                "<tr><td>40-59 cows</td><td> 4-year old she-cow</td></tr>" +
                "<tr><td>60-69 cows</td><td> 2-year old she-cows</td></tr>" +
                "<tr><td>70-79 cows </td><td>Two she-cows (a 2-year old and a 4-year old she-cow)</td></tr>" +
                "<tr><td>80-89 cows</td><td>Two she-cows of 4-years old</td></tr>" +
                "<tr><td>90-99 cows</td><td>Three she-cows of 2-years old</td></tr>" +
                "<tr><td>100-109 cows</td><td>Three she-cows (2 of 2-year old and 1 of 4 -year old)</td></tr>" +
                "<tr><td>110-119 cows</td><td>Three she-cows (2 of 4-year old and 1 of 2-year old)</td></tr>" +
                "<tr><td>120 cows</td><td>Either 3 (4-year old) or 4 (2-year old) she-cows</td></tr></table>"+
                "<br><p align=\"justify\"><b>NB:</b>when the number exceeds 120, there is an option of paying out of a 2-year old she-cow for every" +
                " 30" +
                " cows or a 3-year old she-cow for every 40. Source MORA (2017)<br>"+
               " <p align=\"justify \"><b><center><font color='green'>Zakat due on sheep and goat</font></center></b></p>"+
                "<table border=\"2\">" +
                "<tr><th>QUANTITY OF SHEEP/GOATS</th><th>ZAKAT TO BE PAID</th></tr>" +
                "<tr><td>40-120 sheep/goat</td><td>A 1 year female sheep/goat</td></tr>" +
                "<tr><td>121-200</td><td>Two female sheep/goats of 1 year each</td></tr>" +
                "<tr><td>201 and above</td><td> 1  year old female sheep/goat for each 100</td></tr></table>" +

                "<p align=\"justify \"><b><center><font color='green'><u>Zakat due on farm produces (crops)</u></font></center></b></p>"+
                "<p align=\"justify\">No farm product is liable for Zakat unless it is a product that is considered as a food and can be stocked or saved naturally without refrigeration. If the produce is perishable fruit, such as grapes, there is no Zakat. But if one sells them they will pay their Zakat on the profit earned when it matures.\n" +
                "The nisaab is 612 kilos, which equals 1,346.40 lb. <br>There is no Zakat on produce that is less than this amount. If the farm produce or crops grow dependant on rainwater, or without any man's labour or irrigation, Zakat due is one-tenth of the total. If it is grown by irrigation, then the Zakat due is half of one-tenth of the total produce." +
                " There is no Zakat on fruits like apples or oranges or vegetables which are perishable and need refrigeration for long storage, but they should be considered as any income if the profit earned from their sale reaches the amount of Zakat, then Zakat should be given.\n" +
                "<br>All scholars have agreed that the Nisab for zakatable crops is five (5) awsuq which is equivalent to 300 Sa’is which is equivalent to 1,200 Mudunnabiy. In other words\n" +
                "<br>Wusq\t\t\t\t=\t5\n" +
                "<br>Sa’I\t\t\t\t=\t300\n" +
                "<br>Mudunnabiy\t\t\t =\t1,200\n" +
                "<br><b>Explanation:</b>\n" +
                "MORA(2017), has practically assessed that, 4 mudunnabiy is approximately equal to one of the types of measures commonly " +
                "used in our markets called “kwanonsha”, that means 1 kwanonsha is roughly equals to one Sa’I and 60 kwano  equal to 5 wusq. " +
                "Since 5 wusq is approximately 7.5" +
                " big size sack if you use the sack which contains 40 kwano. \n" +
                "The Zakat on farm produce are giving on the day it is harvested. <br>The due is on two conditions:\n" +
                "<ul><li> <p align=\"justify \">a)One tenth (1/10) if the crop is cultivated with natural (heaven) water and if it reaches the Nisab.</li>" +
                "<li><p align=\"justify \">b)\t One twentieth (1/20) if the crop is cultivated with artificial (irrigation) if it reaches the Nisab.\n</li>" +
                "</ul>"+
                "<p align=\"justify \"><b>Note::</b>\t<br>It must be given out on the day of harvest Allah (SWT) stated: \"O you who believe, give of the good things which you have (honourably) earned, and of the fruits of the earth which We have produced for you...\" (Al-Qur'an, 2: 267) Also: \"... But render the dues that are proper on the day that the harvest is gathered...\" (Al-Qur'an, 6: 141) \n</p>"+

                "<p align=\"justify \"><b><center><font color='green'><u>Zakat due on cash</u></font></center></b></p>"+
               "<p align=\"justify \">The Nisab for all of the above mentioned is the net value of wealth equilavent to the current market value of 85g of gold. To make the work easier, the system will provide the current Nisab (in naira) used by the Zakat of Dutse Emirate Council and it will be modified at any time. This year’s Nisab (2019) is N1.164,899:00.</p>"+
                "</p></body></html>";

//TextView md=findViewById(R.id.md);
        String k;
//k=md.getText().toString();
        view.loadDataWithBaseURL(null, text,"text/html","utf-8",null);


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.mainmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            alertdialog();
            return true;
        }
        if (id == R.id.action_about) {
            Intent intent =  new Intent(mainmenu.this, abt.class);
            startActivity(intent);

        }

        return super.onOptionsItemSelected(item);
    }
    public void alertdialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(mainmenu.this);
        builder.setTitle("Zakat Computation");
        builder.setMessage("Do You Want Exit?").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();

    }
    public void showmessage(){

        android.app.AlertDialog.Builder builder= new android.app.AlertDialog.Builder(this,R.style.alert);
        builder.setCancelable(true);
        builder.setTitle("About us");

        builder.setMessage("            Design BY" +
                "\n NAME: Anas Attahir Haruna\n " +
                "REGISTRATION NUMBER: UG15/COMS/2035\n" +
                "DEPARTMENT OF COMPUTER SCIENCE\n" +
                "KANO UNIVERITY OF SCIENCE AND TECH.\n" +
                "         07037870901");

        builder.show();
    }
    public void aboutdialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(mainmenu.this);
        builder.setTitle("       About us");

        builder.setMessage(" "

        );

        AlertDialog alert=builder.create();
        alert.show();
alert.getWindow().setBackgroundDrawableResource(android.R.color.white);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.share) {
            Intent intent =  new Intent(android.content.Intent.ACTION_SEND);

            intent.setType("text/plain");
            intent.putExtra(android.content.Intent.EXTRA_TEXT,"My new app https://play.google.com/store/search?q=TECHUBINDIAN");
            startActivity(Intent.createChooser(intent,"share via"));
            // Handle the camera action
        } else if (id == R.id.about) {

            Intent intent =  new Intent(mainmenu.this, abt.class);
            startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());

        } else if (id == R.id.money) {
            Intent intent =  new Intent(mainmenu.this, cash.class);
            startActivity(intent);
        } else if (id == R.id.gold) {
            Intent intent =  new Intent(mainmenu.this, goldmenu.class);
            startActivity(intent);
        }

        else if (id == R.id.crop) {
            Intent intent =  new Intent(mainmenu.this, crop.class);
            startActivity(intent);
        }
        else if (id == R.id.livestock) {
            Intent intent =  new Intent(mainmenu.this, livemenu.class);
            startActivity(intent);


        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
