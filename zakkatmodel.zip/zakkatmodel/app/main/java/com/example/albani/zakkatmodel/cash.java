package com.example.albani.zakkatmodel;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.ads.AdView;

public class cash extends AppCompatActivity {
int a,b,c,total;
String m,n,o,p;
EditText name,cash,hand,bank;
Button compute,reset,back;
    private AdView mAdView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cash);

      //  AdRequest adRequest = new AdRequest.Builder().addTestDevice("8CDD0583F6368049671C306111750A46").build();




        mAdView = findViewById(R.id.adView);


        name=findViewById(R.id.name);
        cash=findViewById(R.id.money);
        hand=findViewById(R.id.hand);
        bank=findViewById(R.id.bank);
        compute=findViewById(R.id.btnsave);
add();
    }
    public  void reset(View view){

        name.setText("");
        cash.setText("");
        hand.setText("");
        bank.setText("");
    }
    public  void back(View view){
        Intent Intent = new Intent(getApplicationContext(), mainmenu.class);
        startActivity(Intent);

    }
    public int trypersInt(String value,int dp){

        try {
            return  Integer.parseInt(value);


        }catch (NumberFormatException nfe){return dp; }
    }
    public  void add(){
       compute.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {

                                       String payer = name.getText().toString().trim();

                                        String cc=cash.getText().toString().trim();

                                        String ca =hand.getText().toString().trim();

                                        String cb=bank.getText().toString().trim();

                                        int d=0;

m=name.getText().toString();
n=cash.getText().toString();
o=hand.getText().toString();
p=bank.getText().toString();

                                        c=trypersInt(cc,0);
                                       a= trypersInt(ca,0);
                                       b=trypersInt(cb,0);
                                        d= a + b;
                                    if (m.isEmpty()) {
                                            Toast.makeText(cash.this, "Empty field is not Accepted", Toast.LENGTH_SHORT).show();

                                        }
                                        else if (d < c) {
                                            c = Integer.parseInt(cc);
                                            Toast.makeText(cash.this, "No zakat  for "+d+" amount of money", Toast.LENGTH_LONG).show();
                                        } else {
                                           int m=d/40;
showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Zakkat for N"+d+" is = N"+m+"" );
                                            Toast.makeText(cash.this, "Zakkat for "+name.getText().toString()+" is "+m+"", Toast.LENGTH_LONG).show();
                                        }

                                    }
                                }
        );
    }
    public void showmessage(String title, String message){

        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);

        builder.setMessage(message);

        builder.show();
    }

}
