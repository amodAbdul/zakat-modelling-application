package com.example.albani.zakkatmodel;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Explode;
import android.transition.Transition;
import android.view.Window;

public class abt extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
        Transition transition = new Explode();

        transition.setStartDelay(100);
        transition.setDuration(1000);

        getWindow().setEnterTransition(transition);
        getWindow().setExitTransition(transition);

        setContentView(R.layout.activity_abt);

    }
}
