package com.example.albani.zakkatmodel;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;

public class tem extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    WebView view;
    String text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tem);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        view = findViewById(R.id.web);
        text = "<html><body >" +
                " <img src=\"file:///android_asset/zk2.jpg\" width=\"300\" height=\"120\" /><br> "+
                "<p align=\"justify\"><b><center><font color='green'>WHAT IS ZAKAT</font></center></b>" +
                "</p><p align=\"justify\">Zakkat is fixed portion of wealth out of each and every kind wealth liable to Zakat of a muslims to be paid yearly from reach to the poor for the benefits of Muslims Community." +
                "Zakat Modelling Application Is an automated system that show how to compute different zakat categories in a comportable manner in other to provide easy means for the end user`s to see the benefit of computer " +
                "in zakat processes\"</string>\n </p>" +
                " <br><img src=\"file:///android_asset/zk1.jpg\" width=\"300\" height=\"120\" /> "+
                "<p align=\"justify\"><b><center><font color='green'>Zakat and its Types</font></center></b><hr>" +
                "<p align=\"justify\"> The term Zakat refers to a certain fixed portion of wealth out of each and every kind of wealth liable to Zakat of a Muslim to be paid yearly for the benefit of the poor in the Muslim community. " +
                "The payment of Zakat is obligatory as it is the third pillar of Islam. Zakat is the major economic means" +
                " for establishing social justice and also balances the mode of living between the rich and the poor in Muslim community. " +
                "Different scholars have defined Zakat, among which are:-" +
                "<br><br><b>*1)	Irfan (1996):</b> defined Zakat as the compulsory levy on the income and wealth of Muslim which is meant to clean and purify and signified justness, integrity and vindication as well as increase " +"" +
                "and growth."+
                " <br><b><br>*2)	Mawdudi (1985):</b> defined Zakat as purity and cleanliness and act of setting aside a portion of a Muslim wealth for the needy and poor, with which are attained. He added that Zakat was enjoined by Allah upon Muslims as a test soul enjoined upon the people of Ibrahim (Qur’an21:73)," +
                " Isa (Qur’an19:31) and Isma’il (Qur’an19:55). <br>" +
                "<br><br><b>3)	Isma’il (1990):</b> stated that Zakat literally means growth and cleanliness. It also refers to both the compulsory and voluntary charity as well as feeding others, compulsorily and voluntarily. It was enjoined upon Muslims in the second year of Hijrah, to be collected from the rich and given to the poor."+
                "<br><br><b>*4)	IbnulQayyim (1999):</b> stated Zakat as that portion of a man’s wealth which was designated for to the poor. He again said that it was derived from the Arabic verbal root meaning “to purify”, or “to increase” or “to bless”. He further clarified that it found origin in Allah’s (SWT) command in the Holy Qur’an “take sadaqah (Zakat) from their property and to purify and sanctify them”(Qur’an 9:103)."+
                "<br><br><b>*5)	Samir (2005):</b> stated that, Zakat (alms) is the name of what a believer returns out of his or her wealth to the neediest of Muslims for the sake of the Almighty Allah. It is called Zakat because the word Zakat is from Zakat which means, to increase, purify and bless."+
                "Zakat could therefore, be defined as the third of the five pillars of Islam which is obligatory to every Muslim at a specific amount of wealth at a specific level and given out to a specific group of people among the Muslims."+
                "Zakat is of two types: the obligatory and the non-obligatory (zakatulfitr). This project is concerned with the obligatory one."+
                "<br><br><b>*6)	Hussain (1997):</b> stated that Zakat refers to spending a fixed portion of one's wealth for the poor and needy in the society. Giving money for charity is highly commendable; however zakat is different because it is obligatory."+

                " <br><img src=\"file:///android_asset/islam2.png\" width=\"300\" width=\"10\" /> "+
                "<p align=\"justify \"><b><center><font color='green'>Who is obliged to pay Zakat? </font></center></b></p>"+
                "<p align=\"justify \">All scholars agreed that Zakat is compulsory upon Muslims who are adults, free (not slaves), mentally stable and possess Nisab and Hawl, but opinions differed on orphans, insane and debtors.<br>" +
                "Some scholars like Ali, Ibn Umar, Jabir and Aisha (from the Sahabah) and Malik, Shafi’ (from early scholars after the Sahabahs) agreed that Zakat is compulsory on the wealth of orphans and insane but not slaves (because a slave has no full" +
                " possession of his wealth) and debtors.<br >Sabiq (1995) said that every Muslim who has Nisab possessed for at least one lunar year must pay Zakat. He further added that the guardian of a child and a mentally retarded person must pay Zakat on his behalf from his property if it constitutes Nisab.\n" +

                "From the cited work above, it will be concluded that every Muslim must pay Zakat young or old, male or female sane or insane except according to Malik (1982) and his co-scholars that slave and indebted (whose balance after paying off his debts is less than nisab) cannot pay Zakat.\n </p>"+
                "</p></body></html>";

//TextView md=findViewById(R.id.md);
        String k;
//k=md.getText().toString();
        view.loadDataWithBaseURL(null, text,"text/html","utf-8",null);



        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.tem, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();



        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
