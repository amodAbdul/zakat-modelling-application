package com.example.albani.zakkatmodel;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Explode;
import android.transition.Transition;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class cows extends AppCompatActivity {
    int a,b,c,total;
    String m,n,o,p;
    EditText name,cash,cow,bank;
    Button compute,reset,back;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
        Transition transition = new Explode();

        transition.setStartDelay(250);
        transition.setDuration(800);

        getWindow().setEnterTransition(transition);
        getWindow().setExitTransition(transition);

        setContentView(R.layout.activity_cows);
        name=findViewById(R.id.name);
        cow=findViewById(R.id.cow);

        compute=findViewById(R.id.btnsave);
        add();
    }
    public int trypersInt(String value, int defaultv){

        try {
            return  Integer.parseInt(value);
        }catch (NumberFormatException nfe){return 0; }
    }
    public  void back(View view){
        Intent Intent = new Intent(getApplicationContext(), livemenu.class);
        startActivity(Intent);

    }
    public  void reset(View view){

        name.setText("");
        cow.setText("");

    }
    public  void add(){
        compute.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {

                                           String payer = name.getText().toString().trim();
                                           String md=cow.getText().toString();


                                         int   q= trypersInt(md,0);

                                           b= trypersInt(md,0);
                                           if (payer.equals("")) {
                                               Toast.makeText(cows.this, "Empty field is not Accepted", Toast.LENGTH_SHORT).show();

                                           }
                                           else if (b<30) {

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Sorry, no Zakat for "+b +" Cows" );
                                           }
                                           else if (b>29 && b<40) {

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Cows:"+q+"\n Zakat due is one she-cow of two years old" );
                                           }
                                           else if (b> 39 && b<60){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Cows:"+q+"\n Zakat due is a four-year old she-cow" );
                                           }
                                           else if (b> 59 && b<70){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Cows:"+q+"\n Zakat due are two she-cows (of 2-year each)" );
                                           }

                                           else if (b> 69 && b<80){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Cows:"+q+"\n Zakat due are two she-cows (a 2-year old and a 4-year old)" );
                                           }
                                           else if (b> 79 && b<90){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Cows:"+q+"\n Zakat due are two she-cows (each of 4-year old)" );
                                           }
                                           else if (b> 89 && b<100){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Cows:"+q+"\n Zakat due are three she-cows (two of 2-year old and one of 4-year old)" );
                                           }
                                           else if (b> 99 && b<110){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Cows:"+q+"\n Zakat due are three she-cows (one of 2-year old and two of 4-year old)" );
                                           }
                                           else if (b> 109 && b<120){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Cows:"+q+"\n Zakat due are either three she-cows (of 4-year old) or four she-cows (of 2-year old)" );
                                           }

                                           else{
                                               int c=b/30;
                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Cows:"+q+"\n Zakat due is either "+ c +" she-cows (2-year old each)" );

                                           }

                                       }
                                   }
        );
    }
    public void showmessage(String title, String message){

        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);

        builder.setMessage(message);

        builder.show();
    }

}
