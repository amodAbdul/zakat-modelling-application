package com.example.albani.zakkatmodel;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class dutse extends AppCompatActivity {
    WebView view;
    String text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dutse);

        view = findViewById(R.id.web);
        text = "<html><body >" +
                "<center> <img src=\"file:///android_asset/dutse.jpg\" width=\"300\" height=\"170\" /></center><br> "+
                "<p align=\"justify\"><b><center><font color='green'>THE EMIRE OF DUTSE</font></center></b>" +
                "</p><p align=\"justify\">ALH. DR. NUHU MUHAMMED SANUSI <font color='green'>CON</font> </string>\n<br> </p>" +
                " <br><center><img src=\"file:///android_asset/zk1.jpg\" width=\"300\" height=\"120\" /></center> "+
                "<p align=\"justify \"><b><center><font color='green'><u>DEVELOPED FOR</u></font></center></b></p>"+
                "<p align=\"justify \"> This Application  was developed under the authority of Dutse Emriate council, Zakat Department, that will provide user friendly interface to end user who are able to paid their zakat.</p></body></html>";

//TextView md=findViewById(R.id.md);
        String k;
//k=md.getText().toString();
        view.loadDataWithBaseURL(null, text,"text/html","utf-8",null);


    }
}
