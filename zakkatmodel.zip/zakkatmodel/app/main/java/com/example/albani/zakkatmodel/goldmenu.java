package com.example.albani.zakkatmodel;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.google.android.gms.ads.AdView;

public class goldmenu extends AppCompatActivity {
    private AdView mAdView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goldmenu);
       // MobileAds.initialize(this,
         //       "ca-app-pub-2112847223699649~3362289697");

       // mAdView = findViewById(R.id.adView);


    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void gold(View view){
        Intent intent =  new Intent(goldmenu.this, gold.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());

    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void silver(View view){
        Intent intent =  new Intent(goldmenu.this, silver.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());

    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void back(View view){
        Intent intent =  new Intent(goldmenu.this, mainmenu.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());

    }

}
