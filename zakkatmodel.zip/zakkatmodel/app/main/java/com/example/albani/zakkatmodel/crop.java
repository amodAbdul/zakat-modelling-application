package com.example.albani.zakkatmodel;

import android.app.AlertDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class crop extends AppCompatActivity {
    int a,b,c,total;
    String m,n,o,p;
    EditText name,cash,crop,bank;
    Button compute,reset,back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop);
        name=findViewById(R.id.name);
        crop=findViewById(R.id.crop);
reset=findViewById(R.id.btnreset);
        back=findViewById(R.id.back);
        compute=findViewById(R.id.btnsave);
        add();
        reset();
        back();
    }
    public int trypersInt(String value, int defaultv){

        try {
            return  Integer.parseInt(value);
        }catch (NumberFormatException nfe){return 0; }
    }

public void reset(){
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name.setText("");
                crop.setText("");
            }
        });
}
public void back(){
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Intent = new Intent(getApplicationContext(), mainmenu.class);
                startActivity(Intent);
            }
        });
}
    public  void add(){
        compute.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {

                                           String payer = name.getText().toString().trim();
                                           String md=crop.getText().toString();

                                           b= trypersInt(md,0);
                                           if (payer.equals("")) {
                                               Toast.makeText(crop.this, "Empty field is not Accepted", Toast.LENGTH_SHORT).show();

                                           }
                                           else if (b<5) {

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Sorry, no Zakat for "+b+" Awsaaq" );
                                           }

                                           else{
                                               int t =b/100;
                                               int k=b*60;

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Amount Obtain:"+b+"\nZakat due is either " +t+" Awsaaq\n or  "+k+" Sa'i " );

                                           }

                                       }
                                   }
        );
    }
    public void showmessage(String title, String message){

        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);

        builder.setMessage(message);

        builder.show();
    }

}
