package com.example.albani.zakkatmodel;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.google.android.gms.ads.AdView;

public class livemenu extends AppCompatActivity {
    private AdView mAdView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_livemenu);

    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void camel(View view){
        Intent intent =  new Intent(livemenu.this, camels.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void cow(View view){
        Intent intent =  new Intent(livemenu.this, cows.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void sheep(View view){
        Intent intent =  new Intent(livemenu.this, sheep.class);
        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }

}
