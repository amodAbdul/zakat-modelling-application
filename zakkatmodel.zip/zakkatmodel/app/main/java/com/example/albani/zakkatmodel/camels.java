package com.example.albani.zakkatmodel;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Explode;
import android.transition.Transition;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class camels extends AppCompatActivity {
    int a,b,c,total;
    String m,n,o,p;
    EditText name,cash,camel,bank;
    Button compute,reset,back;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
        Transition transition = new Explode();

        transition.setStartDelay(250);
        transition.setDuration(800);

        getWindow().setEnterTransition(transition);
        getWindow().setExitTransition(transition);
        setContentView(R.layout.activity_camels);
        name=findViewById(R.id.name);
        camel=findViewById(R.id.camel);

        compute=findViewById(R.id.btnsave);
        add();
    }
    public int trypersInt(String value, int defaultv){

        try {
            return  Integer.parseInt(value);
        }catch (NumberFormatException nfe){return 0; }
    }
    public  void back(View view){
        Intent Intent = new Intent(getApplicationContext(), livemenu.class);
        startActivity(Intent);

    }

    public  void add(){
        compute.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {

                                           String payer = name.getText().toString().trim();
String md=camel.getText().toString();



int q= trypersInt(md,0);
                                          b= trypersInt(md,0);
                                           if (payer.equals("")) {
                                               Toast.makeText(camels.this, "Empty field is not Accepted", Toast.LENGTH_SHORT).show();

                                           }
                                           else if (b<5) {

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Camels obtain:"+q+"\n Sorry, no Zakat for "+b +" camels" );
                                           }
                                           else if (b>4 && b<10) {

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Camels obtain:"+q+"\n Zakat due is one sheep/goat of one year old" );
                                           }
                                           else if (b> 9 && b<14){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Camels obtain:"+q+"\n Zakat due are two sheep/goats of one year old" );
                                           }
                                           else if (b> 13 && b<20){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Camels obtain:"+q+"\n Zakat due are three sheep/goats of one year old" );
                                           }
                                           else if (b> 19 && b<25){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Camels obtain:"+q+"\n Zakat due are four sheep/goats of one year old" );
                                           }
                                           else if (b> 24 && b<35){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Camels obtain:"+q+"\n Zakat due is one she-camel of 1-2 year old" );
                                           }
                                           else if (b> 34 && b<45){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Camels obtain:"+q+"\n Zakat due is one she-camel of 2-3 years old" );
                                           }
                                           else if (b> 44 && b<61){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Camels obtain:"+q+"\n Zakat due is one she-camel of 3-4 yearss old" );
                                           }
                                           else if (b> 60 && b<76){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Camels obtain:"+q+"\n Zakat due is one she-camel of 4-5 years old" );
                                           }
                                           else if (b> 75 && b<91){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Camels obtain:"+q+"\n Zakat due are two she-camels of 3-4 years old each" );
                                           }
                                           else if (b> 90 && b<121){

                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Camels obtain:"+q+"n Zakat due are two she-camel 3-4 years old each" );
                                           }
                                           else{
                                               b=b/40;
                                               showmessage("Zakkat Details:","Payer Name:"+name.getText().toString()+"\n Number of Camels obtain:"+q+"\n Zakat due is: "+ b +" she-camels of 2 years each" );

                                           }

                                       }
                                   }
        );
    }
    public void showmessage(String title, String message){

        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);

        builder.setMessage(message);

        builder.show();
    }

}
